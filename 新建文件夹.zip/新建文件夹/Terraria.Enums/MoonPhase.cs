namespace Terraria.Enums;

public enum MoonPhase
{
	Full,
	ThreeQuartersAtLeft,
	HalfAtLeft,
	QuarterAtLeft,
	Empty,
	QuarterAtRight,
	HalfAtRight,
	ThreeQuartersAtRight
}
