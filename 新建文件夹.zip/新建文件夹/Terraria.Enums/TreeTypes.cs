namespace Terraria.Enums;

public enum TreeTypes
{
	None,
	Forest,
	Corrupt,
	Mushroom,
	Crimson,
	Jungle,
	Snow,
	Hallowed,
	Palm,
	PalmCrimson,
	PalmCorrupt,
	PalmHallowed,
	Ash
}
