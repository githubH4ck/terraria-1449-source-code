namespace Terraria.Enums;

public enum TileCuttingContext
{
	Unknown,
	AttackMelee,
	AttackProjectile,
	TilePlacement
}
