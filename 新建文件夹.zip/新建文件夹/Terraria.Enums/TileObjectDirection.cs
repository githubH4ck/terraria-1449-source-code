namespace Terraria.Enums;

public enum TileObjectDirection
{
	None,
	PlaceLeft,
	PlaceRight
}
