namespace Terraria.Enums;

public enum LiquidPlacement
{
	Allowed,
	NotAllowed,
	OnlyInLiquid,
	OnlyInFullLiquid
}
