namespace Terraria.Enums;

public enum TownNPCSpawnResult
{
	Blocked,
	Successful,
	RelocatedHomeless,
	BlockedInfiHousing
}
