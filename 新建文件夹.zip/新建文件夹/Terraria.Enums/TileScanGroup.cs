namespace Terraria.Enums;

public enum TileScanGroup
{
	None,
	Corruption,
	Crimson,
	Hallow,
	TotalGoodEvil
}
