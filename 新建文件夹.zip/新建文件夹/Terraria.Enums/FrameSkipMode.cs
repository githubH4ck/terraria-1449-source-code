namespace Terraria.Enums;

public enum FrameSkipMode
{
	Off,
	On,
	Subtle
}
