namespace Terraria.Enums;

public enum NPCTargetType
{
	None,
	Player,
	NPC,
	PlayerTankPet
}
