namespace Terraria.GameContent;

public interface IOnPlayerJoining
{
	void OnPlayerJoining(int playerIndex);
}
