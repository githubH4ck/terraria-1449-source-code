namespace Terraria.GameContent;

public struct ExtraSeatInfo
{
	public bool IsAToilet;
}
