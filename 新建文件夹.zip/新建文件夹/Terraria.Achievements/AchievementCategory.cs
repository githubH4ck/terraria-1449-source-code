namespace Terraria.Achievements;

public enum AchievementCategory
{
	None = -1,
	Slayer,
	Collector,
	Explorer,
	Challenger
}
