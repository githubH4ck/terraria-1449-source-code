namespace Terraria.Achievements;

public enum TrackerType
{
	Float,
	Int
}
