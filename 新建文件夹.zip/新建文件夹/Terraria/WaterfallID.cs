namespace Terraria;

public static class WaterfallID
{
	public const int Lava = 1;

	public const int Honey = 14;

	public const int Shimmer = 25;
}
