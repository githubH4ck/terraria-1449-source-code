using Terraria.ID;

namespace Terraria;

public delegate void TileChangeReceivedEvent(int x, int y, int count, TileChangeType type);
