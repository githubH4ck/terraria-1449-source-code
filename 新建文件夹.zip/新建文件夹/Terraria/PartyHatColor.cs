namespace Terraria;

public enum PartyHatColor
{
	None = 0,
	Blue = 1,
	Pink = 2,
	Cyan = 3,
	Purple = 4,
	White = 5,
	Count = 5
}
