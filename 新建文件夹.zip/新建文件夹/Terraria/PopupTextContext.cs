namespace Terraria;

public enum PopupTextContext
{
	RegularItemPickup,
	ItemPickupToVoidContainer,
	SonarAlert,
	ItemReforge,
	ItemCraft,
	Advanced
}
