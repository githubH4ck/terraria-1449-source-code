namespace Terraria;

public enum ItemSerializationContext
{
	SavingAndLoading,
	Syncing
}
