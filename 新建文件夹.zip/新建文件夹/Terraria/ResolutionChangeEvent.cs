namespace Terraria;

public delegate void ResolutionChangeEvent(int width, int height);
