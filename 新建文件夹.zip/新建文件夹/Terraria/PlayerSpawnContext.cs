namespace Terraria;

public enum PlayerSpawnContext
{
	ReviveFromDeath,
	SpawningIntoWorld,
	RecallFromItem
}
