namespace Terraria;

public class Ref<T>
{
	public T Value;

	public Ref()
	{
	}

	public Ref(T value)
	{
		Value = value;
	}
}
