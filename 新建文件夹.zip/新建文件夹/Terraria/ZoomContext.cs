namespace Terraria;

public enum ZoomContext
{
	Unscaled,
	World,
	Unscaled_MouseInWorld,
	UI
}
