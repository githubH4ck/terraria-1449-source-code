namespace Terraria.GameContent.Creative;

public struct CreativePowerUIElementRequestInfo
{
	public int PreferredButtonWidth;

	public int PreferredButtonHeight;
}
