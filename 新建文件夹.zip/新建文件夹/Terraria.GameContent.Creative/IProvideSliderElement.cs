using Terraria.UI;

namespace Terraria.GameContent.Creative;

public interface IProvideSliderElement : IPowerSubcategoryElement
{
	UIElement ProvideSlider();
}
