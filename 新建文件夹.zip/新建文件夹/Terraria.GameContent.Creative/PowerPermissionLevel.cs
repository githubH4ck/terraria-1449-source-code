namespace Terraria.GameContent.Creative;

public enum PowerPermissionLevel
{
	LockedForEveryone,
	CanBeChangedByHostAlone,
	CanBeChangedByEveryone
}
