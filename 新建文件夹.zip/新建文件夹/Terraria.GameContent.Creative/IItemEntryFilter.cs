using Terraria.DataStructures;

namespace Terraria.GameContent.Creative;

public interface IItemEntryFilter : IEntryFilter<Item>
{
}
