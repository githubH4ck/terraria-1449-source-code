namespace Terraria.GameContent.Creative;

public class CreativePowerSettings
{
	public static bool ShouldPowersBeElaborated;
}
