namespace Terraria.GameContent.Bestiary;

public interface IBestiaryPrioritizedElement
{
	float OrderPriority { get; }
}
