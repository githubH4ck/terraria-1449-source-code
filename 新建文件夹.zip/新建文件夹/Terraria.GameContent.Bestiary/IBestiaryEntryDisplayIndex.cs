namespace Terraria.GameContent.Bestiary;

public interface IBestiaryEntryDisplayIndex
{
	int BestiaryDisplayIndex { get; }
}
