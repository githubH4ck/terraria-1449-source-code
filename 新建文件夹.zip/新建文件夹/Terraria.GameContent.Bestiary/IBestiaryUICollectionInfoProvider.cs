namespace Terraria.GameContent.Bestiary;

public interface IBestiaryUICollectionInfoProvider
{
	BestiaryUICollectionInfo GetEntryUICollectionInfo();
}
