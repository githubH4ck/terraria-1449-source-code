namespace Terraria.GameContent.Bestiary;

public interface IItemBestiaryInfoElement : IBestiaryInfoElement
{
}
