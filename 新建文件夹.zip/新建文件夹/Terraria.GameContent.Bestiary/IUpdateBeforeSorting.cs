namespace Terraria.GameContent.Bestiary;

public interface IUpdateBeforeSorting
{
	void UpdateBeforeSorting();
}
