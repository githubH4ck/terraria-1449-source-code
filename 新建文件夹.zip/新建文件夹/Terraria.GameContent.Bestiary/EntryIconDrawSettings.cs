using Microsoft.Xna.Framework;

namespace Terraria.GameContent.Bestiary;

public struct EntryIconDrawSettings
{
	public bool IsPortrait;

	public bool IsHovered;

	public Rectangle iconbox;
}
