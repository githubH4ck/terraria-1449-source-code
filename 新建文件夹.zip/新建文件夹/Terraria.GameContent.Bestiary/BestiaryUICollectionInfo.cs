namespace Terraria.GameContent.Bestiary;

public struct BestiaryUICollectionInfo
{
	public BestiaryEntry OwnerEntry;

	public BestiaryEntryUnlockState UnlockState;
}
