namespace Terraria.GameContent.Bestiary;

public enum BestiaryEntryUnlockState
{
	NotKnownAtAll_0,
	CanShowPortraitOnly_1,
	CanShowStats_2,
	CanShowDropsWithoutDropRates_3,
	CanShowDropsWithDropRates_4
}
