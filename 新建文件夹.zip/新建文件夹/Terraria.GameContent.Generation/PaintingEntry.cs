namespace Terraria.GameContent.Generation;

public struct PaintingEntry
{
	public int tileType;

	public int style;
}
