using Terraria.IO;
using Terraria.WorldBuilding;

namespace Terraria.GameContent.Generation;

public delegate void WorldGenLegacyMethod(GenerationProgress progress, GameConfiguration configuration);
