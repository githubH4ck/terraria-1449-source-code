namespace Terraria.GameContent.ItemDropRules;

public interface IProvideItemConditionDescription
{
	string GetConditionDescription();
}
