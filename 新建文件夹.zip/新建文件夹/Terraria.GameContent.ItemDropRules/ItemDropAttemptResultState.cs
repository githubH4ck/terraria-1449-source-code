namespace Terraria.GameContent.ItemDropRules;

public enum ItemDropAttemptResultState
{
	DoesntFillConditions,
	FailedRandomRoll,
	Success,
	DidNotRunCode
}
