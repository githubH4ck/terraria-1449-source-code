namespace Terraria.GameContent.ItemDropRules;

public struct ItemDropAttemptResult
{
	public ItemDropAttemptResultState State;
}
