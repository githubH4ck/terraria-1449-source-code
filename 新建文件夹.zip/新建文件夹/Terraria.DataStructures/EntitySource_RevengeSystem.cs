namespace Terraria.DataStructures;

public class EntitySource_RevengeSystem : IEntitySource
{
}
