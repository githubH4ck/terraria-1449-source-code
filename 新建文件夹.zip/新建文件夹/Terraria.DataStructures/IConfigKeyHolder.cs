namespace Terraria.DataStructures;

public interface IConfigKeyHolder
{
	string NameKey { get; }

	string ConfigKey { get; }
}
