namespace Terraria.DataStructures;

public delegate void ReturnFromRejectionMenuAction();
