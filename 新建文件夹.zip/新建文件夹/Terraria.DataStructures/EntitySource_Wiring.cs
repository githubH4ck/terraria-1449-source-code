namespace Terraria.DataStructures;

public class EntitySource_Wiring : AEntitySource_Tile
{
	public EntitySource_Wiring(int tileCoordsX, int tileCoordsY)
		: base(tileCoordsX, tileCoordsY)
	{
	}
}
