namespace Terraria.DataStructures;

public class JourneyDuplicationItemCreationContext : ItemCreationContext
{
}
