namespace Terraria.DataStructures;

public interface IEntitySource
{
}
