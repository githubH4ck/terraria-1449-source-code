namespace Terraria.DataStructures;

internal interface IFixLoadedData
{
	void FixLoadedData();
}
