namespace Terraria.DataStructures;

public abstract class ItemCreationContext
{
}
