namespace Terraria.DataStructures;

public class EntitySource_ShakeTree : AEntitySource_Tile
{
	public EntitySource_ShakeTree(int tileCoordsX, int tileCoordsY)
		: base(tileCoordsX, tileCoordsY)
	{
	}
}
