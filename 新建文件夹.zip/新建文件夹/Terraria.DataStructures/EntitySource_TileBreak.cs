namespace Terraria.DataStructures;

public class EntitySource_TileBreak : AEntitySource_Tile
{
	public EntitySource_TileBreak(int tileCoordsX, int tileCoordsY)
		: base(tileCoordsX, tileCoordsY)
	{
	}
}
