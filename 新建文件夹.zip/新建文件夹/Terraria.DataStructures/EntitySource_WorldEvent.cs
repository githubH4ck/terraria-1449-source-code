namespace Terraria.DataStructures;

public class EntitySource_WorldEvent : IEntitySource
{
}
