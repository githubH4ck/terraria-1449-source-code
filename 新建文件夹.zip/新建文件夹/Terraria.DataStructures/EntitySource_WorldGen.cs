namespace Terraria.DataStructures;

public class EntitySource_WorldGen : IEntitySource
{
}
