namespace Terraria.DataStructures;

public class EntitySource_DebugCommand : IEntitySource
{
}
