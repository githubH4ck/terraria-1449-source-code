namespace Terraria.DataStructures;

public class SoundPlaySet
{
	public int IntendedCooldown;

	public int SoundType;

	public int SoundStyle;
}
