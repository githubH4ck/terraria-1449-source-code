namespace Terraria.DataStructures;

public class EntitySource_Film : IEntitySource
{
}
