namespace Terraria.DataStructures;

public enum WeaponDrawOrder
{
	BehindBackArm,
	BehindFrontArm,
	OverFrontArm
}
