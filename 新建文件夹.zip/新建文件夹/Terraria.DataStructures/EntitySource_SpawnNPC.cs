namespace Terraria.DataStructures;

public class EntitySource_SpawnNPC : IEntitySource
{
}
