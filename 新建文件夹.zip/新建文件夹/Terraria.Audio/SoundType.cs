namespace Terraria.Audio;

public enum SoundType
{
	Sound,
	Ambient,
	Music
}
