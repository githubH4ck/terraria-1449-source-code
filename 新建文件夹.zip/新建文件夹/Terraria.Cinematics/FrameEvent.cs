namespace Terraria.Cinematics;

public delegate void FrameEvent(FrameEventData evt);
