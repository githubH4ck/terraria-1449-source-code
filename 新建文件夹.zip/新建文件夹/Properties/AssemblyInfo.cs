using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("Terraria")]
[assembly: AssemblyProduct("Terraria")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("Re-Logic")]
[assembly: AssemblyCopyright("Copyright © 2022 Re-Logic")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("f571b16a-2c9b-44ab-b115-7c762c9e4e7e")]
[assembly: AssemblyFileVersion("1.4.4.9")]
[assembly: AssemblyVersion("1.4.4.9")]
