namespace Terraria.GameContent.Biomes.CaveHouse;

public enum HouseType
{
	Wood,
	Ice,
	Desert,
	Jungle,
	Mushroom,
	Granite,
	Marble
}
