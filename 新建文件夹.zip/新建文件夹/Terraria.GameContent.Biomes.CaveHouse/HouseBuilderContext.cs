namespace Terraria.GameContent.Biomes.CaveHouse;

public class HouseBuilderContext
{
	public int SharpenerCount;

	public int ExtractinatorCount;
}
