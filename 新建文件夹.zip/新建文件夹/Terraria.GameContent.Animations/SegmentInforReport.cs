namespace Terraria.GameContent.Animations;

public struct SegmentInforReport
{
	public int totalTime;
}
